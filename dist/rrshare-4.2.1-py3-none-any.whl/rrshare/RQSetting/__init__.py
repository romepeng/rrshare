from rrshare.RQSetting.rqLocalize import (rq_path, setting_path, cache_path, log_path,
                                        make_dir_path)
