from rrshare.rqFactor import update_swl_all_main


def record_swl_rs_valuation():
    update_swl_all_main()


if __name__ == '__main__':
    record_swl_rs_valuation()
