#!/usr/bin/env python

/usr/bin/python /home/rome/rrshare/rrshare/record_all_data.py









